﻿
Partial Class Events
    Inherits System.Web.UI.Page


    Protected Sub Calendar1_SelectionChanged(sender As Object, e As EventArgs) Handles Calendar1.SelectionChanged
        'when calender changes
    End Sub
End Class
