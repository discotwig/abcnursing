﻿
Partial Class AdminUserProfile
    Inherits System.Web.UI.Page

End Class
