﻿Imports System.Data.SqlClient
Partial Class Analytics
    Inherits System.Web.UI.Page

End Class
