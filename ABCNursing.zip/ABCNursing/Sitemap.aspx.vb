﻿
Partial Class Sitemap
    Inherits System.Web.UI.Page

End Class
