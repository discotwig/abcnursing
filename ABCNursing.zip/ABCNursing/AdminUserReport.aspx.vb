﻿
Partial Class AdminReport
    Inherits System.Web.UI.Page

End Class
