﻿
Partial Class Learn
    Inherits System.Web.UI.Page

End Class
