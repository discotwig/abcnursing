﻿
Partial Class Profile
    Inherits System.Web.UI.Page
    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
        Dim UpPath As String
        Dim UpName As String
        UpPath = "C:\Users\IS 4880\Documents\GitHub\abcnursing\ABCNursing\UserProfile"
        UpName = Dir(UpPath, vbDirectory)
        If (UpName = "") Then
            MkDir("C:\Users\IS 4880\Documents\GitHub\abcnursing\ABCNursing\UserProfile")
        End If
    End Sub
    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        FileName.InnerHtml = FileField.PostedFile.FileName
        FileContent.InnerHtml = FileField.PostedFile.ContentType
        FileSize.InnerHtml = FileField.PostedFile.ContentLength
        UploadDetails.Visible = True
        Dim myFileName As String
        myFileName = FileField.PostedFile.FileName
        Dim c As String = System.IO.Path.GetFileName(myFileName)

        Try
            FileField.PostedFile.SaveAs("C:\Users\IS 4880\Documents\GitHub\abcnursing\ABCNursing\UserProfile\" + c)
            span1.InnerHtml = "Data has been saved sucessfully."

            UploadDetails.Visible = False
        Catch ex As Exception

        End Try


    End Sub
End Class
